package com.rhc.insurance.repositories;

import java.util.Collection;

import com.rhc.insurance.Member;

public interface MemberRepository {

	public Collection<Member> getMembers();

}
